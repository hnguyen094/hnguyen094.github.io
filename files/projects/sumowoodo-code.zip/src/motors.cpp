#include <Arduino.h>
#include "constants.cpp"

const int MOTOR_HIGH = pow(2, MOTOR_RESOLUTION) - 1;
const int MOTOR_LOW = 0;

class MotorControl {
    private:
    bool checkPowerValue(int power) {
        if (power > pow(2, MOTOR_HIGH) || power < 0) {
            Serial.printf("ERROR: power to motor can only be between [0-%d]\n", MOTOR_HIGH);
            return false;
        }
        return true;
    }
    bool dir1 = false;
    int pow1 = MOTOR_LOW;
    bool dir2 = false;
    int pow2 = MOTOR_LOW;

    public:

    /*Setups motor pins (for power and direction.) */
    MotorControl() {
        pinMode(MOTOR_IN1_PIN, OUTPUT);
        pinMode(MOTOR_IN2_PIN, OUTPUT);
        pinMode(MOTOR_ENA_PIN, OUTPUT);
        pinMode(MOTOR_ENB_PIN, OUTPUT);
        pinMode(MOTOR_IN3_PIN, OUTPUT);
        pinMode(MOTOR_IN4_PIN, OUTPUT);
    }

    /* Controls motor1. */
    void motor1Write(bool isForward, int power) {
        Serial.printf("Motor1 dir:%d, pow:%d\n", isForward, power);
        if (!checkPowerValue(power)) {
            return;
        }
        if (power == 0) { // dynamic breaking
            digitalWrite(MOTOR_IN1_PIN, isForward);
            digitalWrite(MOTOR_IN2_PIN, isForward);
            return;
        }
        analogWriteResolution(MOTOR_RESOLUTION);
        analogWrite(MOTOR_ENA_PIN, power);
        digitalWrite(MOTOR_IN1_PIN, !isForward);
        digitalWrite(MOTOR_IN2_PIN, isForward);
        dir1 = isForward;
        pow1 = power;
    }
    
    /* Controls motor2. */
    void motor2Write(bool isForward, int power) {
        Serial.printf("Motor2 dir:%d, pow:%d\n", isForward, power);
        if(!checkPowerValue(power)) {
            return;
        }
        if (power == 0) { // dynamic breaking
            digitalWrite(MOTOR_IN3_PIN, isForward);
            digitalWrite(MOTOR_IN4_PIN, isForward);
            return;
        }
        analogWriteResolution(MOTOR_RESOLUTION);
        analogWrite(MOTOR_ENB_PIN, power);
        digitalWrite(MOTOR_IN3_PIN, isForward);
        digitalWrite(MOTOR_IN4_PIN, !isForward);
        dir2 = isForward;
        pow2 = power;
    }
    
    bool getDir1() {
        return dir1;
    }

    bool getDir2() {
        return dir2;
    }

    int getPow1() {
        return pow1;
    }

    int getPow2() {
        return pow2;
    }
};
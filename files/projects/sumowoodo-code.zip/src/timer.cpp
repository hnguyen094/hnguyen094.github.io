#include <Arduino.h>

class CustomTimer {
    private:
    enum state {stopped, going};
    elapsedMillis timeCounter;
    int oldTimeMillis = 0;
    int currentTime;
    int currentState = going;
    int timeMillis;
    
    public:
    bool expired = false;

    CustomTimer(int timeInMillis) {
        timeMillis = timeInMillis;
        reset();
    }

    void resume() {
        currentState = going;
    }

    void pause() {
        currentState = stopped;
    }

    /* Reset will also pauses. */
    void reset() {
        currentTime = timeMillis;
        expired = false;
        pause();
    }

    /* Needs to be called in main loop! */
    void loop() {
        if (currentState == going) {
            currentTime -= deltaTime();
        } else {
            oldTimeMillis = 0;
            timeCounter = 0;
        }
        expired = currentTime < 0;
    }

    private:
    int deltaTime() {
        int deltaTime = timeCounter - oldTimeMillis;
        oldTimeMillis = timeCounter;
        return deltaTime;
    }
};
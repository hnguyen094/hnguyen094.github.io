/* Pins */
#define MOTOR_IN1_PIN (14)
#define MOTOR_IN2_PIN (15)
#define MOTOR_ENA_PIN (16)
#define MOTOR_ENB_PIN (17)
#define MOTOR_IN3_PIN (18)
#define MOTOR_IN4_PIN (19)

#define IR_SENSOR_PIN (20)

#define LINE_SENSOR1_PIN (21)
#define LINE_SENSOR2_PIN (22)

#define LIMIT_SENSOR1_PIN (10)
#define LIMIT_SENSOR2_PIN (11)


/* Resolutions */
#define IR_RESOLUTION (8)
#define LINE_RESOLUTION (8)
#define MOTOR_RESOLUTION (8)

/* Hysteresis */
#define IR_LOWER_TRIP_PERCENT (0.015f)
#define IR_HIGHER_TRIP_PERCENT (0.039f)

#define LINE_LOWER_TRIP_PERCENT (0.31f)
#define LINE_HIGHER_TRIP_PERCENT (0.39f)

/* Other */
#define TIMER_LENGTH (3000)
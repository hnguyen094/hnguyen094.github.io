#include <Arduino.h>
#include "timer.cpp"
#include "motors.cpp"
#include "sensors.cpp"

/* State of the robot. Add more as needed. */
enum State {
  Setup,
  Orienting,
  TowardsWall1,
  Reorient1,
  PushingWall1,
  TowardsWall2,
  Reorient2,
  PushingWall2
};
State currentState = Setup;
State prevState = Setup;

/* Logic for creating our own timer here. See timer.cpp */
CustomTimer timer(TIMER_LENGTH);
/* Logic associated with motor control. See motors.cpp */
MotorControl mc;
SensorReader sr;

/* Logic for debugging mode. */
int samplesPeriod = 1000; // prints once every samplesPeriod
int curSample = 0;

void setup() {
}

/* handles ONLY state transitions, but doesn't actually do anything. 
 * Returns true if there needs to be any state transitions. 
 * */
bool checkState() {
  switch (currentState) {
    case Setup:
      currentState = Orienting;
      break;

    case Orienting:
      if (sr.irDigitalRead() == HIGH) {
        currentState = TowardsWall1;
      }
      break;

    case TowardsWall1:
      if (sr.line1DigitalRead() == HIGH) {
        currentState = Reorient1;
      } else if (sr.limit1DigitalRead() == HIGH) {
        currentState = PushingWall1;
      }
      break;

    case Reorient1:
      if (sr.line1DigitalRead() == LOW) {
        currentState = TowardsWall1;
      }
      break;
    case PushingWall1:
      if (sr.line1DigitalRead() == HIGH) {
        currentState = Reorient1;
      } else if (timer.expired) {
        currentState = TowardsWall2;
      }
      break;

    case TowardsWall2:
      if (sr.line2DigitalRead() == HIGH) {
        currentState = Reorient2;
      } else if (sr.limit2DigitalRead() == HIGH) {
        currentState = PushingWall2;
      }
      break;

    case Reorient2:
      if (sr.limit2DigitalRead() == LOW) {
        currentState = TowardsWall2;
      }
      break;

    case PushingWall2:
      if (sr.line2DigitalRead() == HIGH) {
        currentState = Reorient2;
      }
      break;
      
    default:
      Serial.printf("ERROR: We should never get here! Did you add a state without casing for it?");
  }
  return currentState != prevState;
}

/* handles only what happens AFTER state transitioning. */
void changeState() {
  switch (currentState) {
    case Setup:
      Serial.print("ERROR: Did you try to change state to Setup? Do you mean Orienting?");
      break;

    case Orienting:
      Serial.println("Orienting");
      mc.motor1Write(true, MOTOR_HIGH / 2);
      mc.motor2Write(false, MOTOR_HIGH / 2);
      break;

    case TowardsWall1:
      Serial.println("TowardWall1");
      mc.motor1Write(true, MOTOR_HIGH /2);
      mc.motor2Write(true, MOTOR_HIGH /2);
      break;

    case Reorient1:
      Serial.println("Reorient1");
      mc.motor1Write(true, MOTOR_LOW);
      mc.motor2Write(false, MOTOR_HIGH);
      timer.pause();
      break;

    case PushingWall1:
      Serial.println("PushingWall1");
      mc.motor1Write(true, MOTOR_HIGH);
      mc.motor2Write(true, MOTOR_HIGH);
      timer.resume();
      break;

    case TowardsWall2:
      Serial.println("TowardsWall2");
      mc.motor1Write(false, MOTOR_HIGH / 2);
      mc.motor2Write(false, MOTOR_HIGH / 2);
      break;

    case Reorient2:
      Serial.println("Reorient2");
      mc.motor1Write(false, MOTOR_LOW);
      mc.motor2Write(true, MOTOR_HIGH);
      break;

    case PushingWall2:
      Serial.println("PushingWall2");
      mc.motor1Write(false, MOTOR_HIGH);
      mc.motor2Write(false, MOTOR_HIGH);
      break;

    default:
      Serial.print("ERROR: We should never get here! Did you add a state without casing for it?");
  }
  prevState = currentState;
}

void interactiveDebuggingMode() {
  if (Serial.available()) {
      byte incomingByte = Serial.read();  // will not be -1
      if (incomingByte == 'r') {
        mc.motor1Write(!mc.getDir1(), mc.getPow1());
        mc.motor2Write(!mc.getDir2(), mc.getPow2());
      } else if (incomingByte == 'k') {
        mc.motor1Write(mc.getDir1(), (mc.getPow1() + 10) % MOTOR_HIGH);
        mc.motor2Write(mc.getDir2(), (mc.getPow2() + 10) % MOTOR_HIGH);
      } else if (incomingByte == 'j') {
        mc.motor1Write(mc.getDir1(), (mc.getPow1() - 10) % MOTOR_HIGH);
        mc.motor2Write(mc.getDir2(), (mc.getPow2() - 10) % MOTOR_HIGH);
      } else if (incomingByte == 's') {
        mc.motor1Write(mc.getDir1(), 0);
        mc.motor2Write(mc.getDir2(), 0);
      }
    }
    if (curSample % 10000 /*samplesPeriod*/ == 0) {
      Serial.printf("LineSensor1 is: %d/%d\t", sr.line1DigitalRead(), sr.line1AnalogRead());
      Serial.printf("LineSensor2 is: %d/%d\t", sr.line2DigitalRead(), sr.line2AnalogRead());
      Serial.printf("IRSensor is: %d%d\t", sr.irDigitalRead(), sr.irAnalogRead());
      Serial.printf("LimitSensor1 is: %d\t", sr.limit1DigitalRead());
      Serial.printf("LimitSensor2 is: %d \n", sr.limit2DigitalRead());
    }
    curSample += 1;
}

void dance() {
    mc.motor1Write(true, MOTOR_HIGH / 2);
    mc.motor2Write(true, MOTOR_HIGH / 2);
    delay(1000);
    mc.motor1Write(false, MOTOR_HIGH / 2);
    mc.motor2Write(false, MOTOR_HIGH / 2);
    delay(1000);
    mc.motor1Write(true, MOTOR_HIGH / 2);
    mc.motor2Write(false, MOTOR_HIGH / 2);
    delay(1000);
    mc.motor1Write(false, MOTOR_HIGH / 2);
    mc.motor2Write(true, MOTOR_HIGH / 2);
    delay(1000);
    mc.motor1Write(false, 0);
    mc.motor2Write(true, 0);
    delay(1000);
}

void loop() {
   timer.loop();
  if (checkState()) {
    changeState();
  }
  
  // Tethered, debugging mode. The above needs to be commented out
  // for the below to have expected behavior.
  // interactiveDebuggingMode();
  // dance();
}
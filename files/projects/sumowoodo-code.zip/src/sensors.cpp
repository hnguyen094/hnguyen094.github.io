#include <Arduino.h>
#include "constants.cpp"

class SensorReader {
    private:
    /**************** Private Line Sensor Values & Functions ****************/
    const int LINE_HIGH = pow(2, LINE_RESOLUTION) - 1;
    const int LINE_LOW = 0;
    // the last/current states, used for hysteresis
    int line1State = 0; 
    int line2State = 0;

    /* NOTE: only works with the two line pins defined! Undefined otherwise. */
    int lineDigitalRead(int pin) {
        int* state = (pin == LINE_SENSOR1_PIN) ? &line1State : &line2State;
        int val = analogRead(pin);
        if (*state == LOW && val > LINE_HIGHER_TRIP_PERCENT * LINE_HIGH) {
            *state = HIGH;
        } else if (*state == HIGH && val < LINE_LOWER_TRIP_PERCENT * LINE_HIGH) {
            *state = LOW;
        }
        return *state;
    }

    /**************** Private IR Sensor Values ****************/
    const int IR_HIGH = pow(2, IR_RESOLUTION) - 1;
    const int IR_LOW = 0;
    int irState = 0;

    public:
    SensorReader() {
        pinMode(LINE_SENSOR1_PIN, INPUT);
        pinMode(LINE_SENSOR2_PIN, INPUT);
        
        pinMode(IR_SENSOR_PIN, INPUT);

        pinMode(LIMIT_SENSOR1_PIN, INPUT);
        pinMode(LIMIT_SENSOR2_PIN, INPUT);
    }

    int line1DigitalRead() {
        analogReadResolution(LINE_RESOLUTION);
        return lineDigitalRead(LINE_SENSOR1_PIN);
    }

    int line2DigitalRead() {
        analogReadResolution(LINE_RESOLUTION);
        return lineDigitalRead(LINE_SENSOR2_PIN);
    }

    int line1AnalogRead() {
        analogReadResolution(LINE_RESOLUTION);
        return analogRead(LINE_SENSOR1_PIN);
    }

    int line2AnalogRead() {
        analogReadResolution(LINE_RESOLUTION);
        return analogRead(LINE_SENSOR2_PIN);
    }

    int irDigitalRead() {
        analogReadResolution(IR_RESOLUTION);
        int val = analogRead(IR_SENSOR_PIN);
        if (irState == LOW && val > IR_HIGHER_TRIP_PERCENT * IR_HIGH) {
            irState = HIGH;
        } else if (irState == HIGH && val < IR_LOWER_TRIP_PERCENT * IR_HIGH) {
            irState = LOW;
        }
        return irState;
    }

    int irAnalogRead() {
        analogReadResolution(IR_RESOLUTION);
        return analogRead(IR_SENSOR_PIN);
    }

    int limit1DigitalRead() {
        return digitalRead(LIMIT_SENSOR1_PIN);
    }

    int limit2DigitalRead() {
        return digitalRead(LIMIT_SENSOR2_PIN);
    }
};